package com.example.azkary

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

data class Dhikr(val text: String, val count: Int)

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("azkary", Context.MODE_PRIVATE) }
    private val morning = listOf(
        Dhikr("أصبحنا وأصبح الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.", 1),
        Dhikr("اللهم بك أصبحنا وبك أمسينا وبك نحيا وبك نموت وإليك النشور.", 1),
        Dhikr("رضيت بالله ربًا، وبالإسلام دينًا، وبمحمد ﷺ نبيًا.", 3),
        Dhikr("سبحان الله وبحمده.", 100)
    )
    private val evening = listOf(
        Dhikr("أمسينا وأمسى الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.", 1),
        Dhikr("اللهم بك أمسينا وبك أصبحنا وبك نحيا وبك نموت وإليك المصير.", 1),
        Dhikr("رضيت بالله ربًا، وبالإسلام دينًا، وبمحمد ﷺ نبيًا.", 3),
        Dhikr("سبحان الله وبحمده.", 100)
    )
    private val prayer = listOf(
        Dhikr("أستغفر الله.", 3),
        Dhikr("اللهم أنت السلام ومنك السلام، تباركت يا ذا الجلال والإكرام.", 1),
        Dhikr("لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.", 1),
        Dhikr("سبحان الله والحمد لله والله أكبر.", 33)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<Button>(R.id.tasbeeh).setOnClickListener { tasbeehDialog() }
        findViewById<Button>(R.id.morning).setOnClickListener { adhkarDialog("أذكار الصباح", morning) }
        findViewById<Button>(R.id.evening).setOnClickListener { adhkarDialog("أذكار المساء", evening) }
        findViewById<Button>(R.id.prayer).setOnClickListener { adhkarDialog("أذكار بعد الصلاة", prayer) }
        findViewById<Button>(R.id.favorites).setOnClickListener { favoritesDialog() }
        findViewById<Button>(R.id.settings).setOnClickListener { settingsDialog() }
    }

    private fun tasbeehDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(30,20,30,20) }
        val phrase = TextView(this).apply { text = "سبحان الله"; textSize = 27f; gravity = Gravity.CENTER; setPadding(5,15,5,15) }
        val count = TextView(this).apply { textSize = 52f; gravity = Gravity.CENTER; setPadding(5,10,5,20) }
        val target = TextView(this).apply { textSize = 15f; gravity = Gravity.CENTER }
        var n = prefs.getInt("tasbeeh_count", 0)
        fun refresh() { count.text = n.toString(); target.text = "الهدف: 100" }
        refresh()
        val tap = Button(this).apply { text = "📿  سَبِّح"; textSize = 22f; setOnClickListener {
            n++; prefs.edit().putInt("tasbeeh_count", n).apply(); refresh()
        }}
        val reset = Button(this).apply { text = "إعادة العداد"; setOnClickListener {
            n = 0; prefs.edit().putInt("tasbeeh_count", 0).apply(); refresh()
        }}
        box.addView(phrase); box.addView(count); box.addView(target); box.addView(tap); box.addView(reset)
        AlertDialog.Builder(this).setTitle("التسبيح").setView(box).setPositiveButton("إغلاق", null).show()
    }

    private fun adhkarDialog(title: String, list: List<Dhikr>) {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(25,10,25,10) }
        list.forEachIndexed { i, d ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0,12,0,12) }
            val text = TextView(this).apply { this.text = "${i+1}. ${d.text}"; textSize = 19f; setTextColor(getColor(R.color.text)); setPadding(0,0,0,8) }
            val action = Button(this).apply { text = "تم × ${d.count}"; setOnClickListener {
                text.alpha = 0.55f
                it.isEnabled = false
            }}
            row.addView(text); row.addView(action); layout.addView(row)
        }
        val scroll = ScrollView(this).apply { addView(layout) }
        AlertDialog.Builder(this).setTitle(title).setView(scroll).setPositiveButton("إغلاق", null).show()
    }

    private fun favoritesDialog() {
        AlertDialog.Builder(this).setTitle("المفضلة")
            .setMessage("لم تتم إضافة أذكار للمفضلة بعد.
يمكننا إضافة نظام المفضلة المتقدم في تحديث لاحق.")
            .setPositiveButton("حسنًا", null).show()
    }

    private fun settingsDialog() {
        AlertDialog.Builder(this).setTitle("الإعدادات")
            .setItems(arrayOf("الوضع الليلي", "اهتزاز عند التسبيح", "حول التطبيق")) { _, which ->
                if (which == 0) Toast.makeText(this, "يمكن تفعيل الوضع الليلي من إعدادات الهاتف في هذه النسخة.", Toast.LENGTH_LONG).show()
                if (which == 1) Toast.makeText(this, "إعداد الاهتزاز جاهز للإضافة في التحديث القادم.", Toast.LENGTH_LONG).show()
                if (which == 2) Toast.makeText(this, "أذكاري – الإصدار 1.0", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("إغلاق", null).show()
    }
}
